import unittest

from content_engine.mock import mock_week


class TestMock(unittest.TestCase):
    def test_counts(self):
        week = mock_week("x", "Audience")
        self.assertEqual(len(week.hooks), 5)
        self.assertEqual(len(week.reels), 3)
        self.assertEqual(len(week.carousels), 2)
        self.assertEqual(len(week.captions), 3)
        self.assertIn(len(week.story.frames), (3, 4))

    def test_carousel_slide_counts(self):
        week = mock_week("x")
        for carousel in week.carousels:
            self.assertTrue(5 <= len(carousel.slides) <= 7)

    def test_caption_hashtags(self):
        week = mock_week("x")
        for caption in week.captions:
            self.assertTrue(5 <= len(caption.hashtags) <= 8)
            for tag in caption.hashtags:
                self.assertFalse(tag.startswith("#"))

    def test_gap_recorded(self):
        self.assertEqual(mock_week("x", "Visibility").gap, "Visibility")


if __name__ == "__main__":
    unittest.main()
