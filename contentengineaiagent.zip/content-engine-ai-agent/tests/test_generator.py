import json
import sys
import types
import unittest
from types import SimpleNamespace

from content_engine import generator
from content_engine.mock import mock_week


class TestCheckCounts(unittest.TestCase):
    def test_no_warnings_on_correct_counts(self):
        self.assertEqual(generator._check_counts(mock_week("x")), ())

    def test_warns_on_wrong_counts(self):
        week = mock_week("x")
        week.hooks = week.hooks[:3]  # only 3 hooks now
        warnings = generator._check_counts(week)
        self.assertTrue(any("hooks" in w for w in warnings))


class _FakeMessages:
    def __init__(self, payload, captured):
        self._payload = payload
        self._captured = captured

    def create(self, **kwargs):
        self._captured.update(kwargs)
        return SimpleNamespace(
            content=[SimpleNamespace(type="thinking", thinking="..."),
                     SimpleNamespace(type="text", text=json.dumps(self._payload))],
            stop_reason="end_turn",
            usage=SimpleNamespace(input_tokens=100, output_tokens=200),
        )


class TestGenerateWiring(unittest.TestCase):
    """Inject a fake `anthropic` module to verify request shape + parsing
    without hitting the network or needing the real SDK installed."""

    def setUp(self):
        self.captured = {}
        payload = mock_week("the system", "Conversion").to_dict()
        fake = types.ModuleType("anthropic")

        captured = self.captured

        class FakeClient:
            def __init__(self, **kw):
                self.messages = _FakeMessages(payload, captured)

        fake.Anthropic = FakeClient
        self._real = sys.modules.get("anthropic")
        sys.modules["anthropic"] = fake

    def tearDown(self):
        if self._real is not None:
            sys.modules["anthropic"] = self._real
        else:
            sys.modules.pop("anthropic", None)

    def test_generate_builds_correct_request_and_parses(self):
        week, meta = generator.generate(
            "the system", gap="Conversion", model="claude-opus-4-8", api_key="test"
        )
        # Parsing worked
        self.assertEqual(len(week.hooks), 5)
        self.assertEqual(week.gap, "Conversion")
        self.assertEqual(meta.model, "claude-opus-4-8")
        self.assertEqual(meta.output_tokens, 200)

        # Request shape is correct
        c = self.captured
        self.assertEqual(c["model"], "claude-opus-4-8")
        self.assertEqual(c["thinking"], {"type": "adaptive"})
        self.assertEqual(c["output_config"]["format"]["type"], "json_schema")
        self.assertIn("schema", c["output_config"]["format"])
        self.assertEqual(c["output_config"]["effort"], "high")
        self.assertEqual(c["messages"][0]["role"], "user")
        self.assertIn("the system", c["messages"][0]["content"])
        self.assertIn("Meta Neo Academy", c["system"])


if __name__ == "__main__":
    unittest.main()
