import unittest

from content_engine.mock import mock_week
from content_engine.renderer import to_email_html, to_markdown


class TestRenderer(unittest.TestCase):
    def setUp(self):
        self.week = mock_week("the 3 gap framework", "Conversion")

    def test_markdown_has_all_sections(self):
        md = to_markdown(self.week, model="MOCK")
        for heading in (
            "## 1. Hooks",
            "## 2. Reel scripts",
            "## 3. Carousels",
            "## 4. Captions",
            "## 5. Story sequence",
        ):
            self.assertIn(heading, md)

    def test_markdown_includes_topic_and_hashtags(self):
        md = to_markdown(self.week)
        self.assertIn("the 3 gap framework", md)
        self.assertIn("#socialmediamarketing", md)  # hashtags get the # back

    def test_markdown_lists_all_hooks(self):
        md = to_markdown(self.week)
        for i in range(1, 6):
            self.assertIn(f"{i}. ", md)

    def test_email_html_escapes_and_has_body(self):
        html = to_email_html(self.week)
        self.assertIn("<h1", html)
        self.assertIn("the 3 gap framework", html)
        # ampersands etc. would be escaped; ensure it's a non-trivial body
        self.assertGreater(len(html), 200)


if __name__ == "__main__":
    unittest.main()
