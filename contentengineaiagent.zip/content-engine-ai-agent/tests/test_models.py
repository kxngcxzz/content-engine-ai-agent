import unittest

from content_engine.mock import mock_week
from content_engine.models import Caption, ContentError, ContentWeek


class TestModels(unittest.TestCase):
    def test_round_trip(self):
        week = mock_week("growth", "Conversion")
        rebuilt = ContentWeek.from_dict(week.to_dict())
        self.assertEqual(rebuilt.topic, "growth")
        self.assertEqual(rebuilt.gap, "Conversion")
        self.assertEqual(len(rebuilt.hooks), 5)
        self.assertEqual(rebuilt.to_dict(), week.to_dict())

    def test_missing_field_raises(self):
        with self.assertRaises(ContentError):
            ContentWeek.from_dict({"topic": "x"})  # missing everything else

    def test_wrong_type_raises(self):
        with self.assertRaises(ContentError):
            Caption.from_dict(
                {
                    "first_line": "hi",
                    "body_paragraphs": "not a list",  # should be a list
                    "soft_cta": "cta",
                    "hashtags": [],
                }
            )

    def test_hashtags_are_stripped_of_hash(self):
        cap = Caption.from_dict(
            {
                "first_line": "hi",
                "body_paragraphs": ["p"],
                "soft_cta": "cta",
                "hashtags": ["#alpha", "beta"],
            }
        )
        self.assertEqual(cap.hashtags, ["alpha", "beta"])

    def test_count_summary(self):
        summary = mock_week("x").count_summary()
        self.assertIn("5 hooks", summary)
        self.assertIn("3 reels", summary)


if __name__ == "__main__":
    unittest.main()
