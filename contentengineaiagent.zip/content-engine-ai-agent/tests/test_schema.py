import unittest

from content_engine.mock import mock_week
from content_engine.schema import CONTENT_WEEK_SCHEMA


def _instance_matches(instance, schema, path="root"):
    t = schema["type"]
    if t == "object":
        assert isinstance(instance, dict), f"{path}: expected object"
        props = schema["properties"]
        for key in schema.get("required", []):
            assert key in instance, f"{path}: missing required {key}"
        if schema.get("additionalProperties") is False:
            extra = set(instance) - set(props)
            assert not extra, f"{path}: unexpected keys {extra}"
        for key, val in instance.items():
            _instance_matches(val, props[key], f"{path}.{key}")
    elif t == "array":
        assert isinstance(instance, list), f"{path}: expected array"
        for i, item in enumerate(instance):
            _instance_matches(item, schema["items"], f"{path}[{i}]")
    elif t == "string":
        assert isinstance(instance, str), f"{path}: expected string"
    else:
        raise AssertionError(f"{path}: unknown schema type {t}")


def _check_strictness(schema, path="root"):
    """Every object must declare additionalProperties:false and list all of
    its properties in required — the Messages API structured-output contract."""
    t = schema["type"]
    if t == "object":
        assert schema.get("additionalProperties") is False, f"{path}: needs additionalProperties:false"
        props = set(schema["properties"])
        required = set(schema.get("required", []))
        assert props == required, f"{path}: required must equal properties ({props ^ required})"
        for key, sub in schema["properties"].items():
            _check_strictness(sub, f"{path}.{key}")
    elif t == "array":
        _check_strictness(schema["items"], f"{path}[]")


class TestSchema(unittest.TestCase):
    def test_schema_is_strict_everywhere(self):
        _check_strictness(CONTENT_WEEK_SCHEMA)

    def test_mock_week_conforms_to_schema(self):
        _instance_matches(mock_week("topic", "Conversion").to_dict(), CONTENT_WEEK_SCHEMA)


if __name__ == "__main__":
    unittest.main()
