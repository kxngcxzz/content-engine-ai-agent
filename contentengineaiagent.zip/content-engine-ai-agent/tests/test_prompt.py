import unittest

from content_engine.prompt import build_user_prompt, load_system_prompt


class TestPrompt(unittest.TestCase):
    def test_system_prompt_loads_and_is_on_brand(self):
        sp = load_system_prompt()
        self.assertIn("Meta Neo Academy", sp)
        self.assertIn("entrepreneurs", sp)
        self.assertIn("British spelling", sp)
        self.assertIn("3 Gap Framework", sp)

    def test_user_prompt_includes_inputs(self):
        up = build_user_prompt(
            "hooks that convert",
            gap="Conversion",
            emphasis="beginner-friendly",
            source_text="chapter text here",
        )
        self.assertIn("hooks that convert", up)
        self.assertIn("Conversion", up)
        self.assertIn("beginner-friendly", up)
        self.assertIn("chapter text here", up)

    def test_user_prompt_states_counts_and_ctas(self):
        up = build_user_prompt("topic")
        self.assertIn("exactly 5 hooks", up.lower())
        self.assertIn("Social Media Monetisation 2026", up)


if __name__ == "__main__":
    unittest.main()
