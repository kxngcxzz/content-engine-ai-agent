import os
import unittest

from content_engine.integrations import (
    ALL_TARGETS,
    INTEGRATIONS,
    configured_targets,
    resolve_targets,
    run_pushes,
)
from content_engine.integrations import mailchimp, notion
from content_engine.mock import mock_week

# Service env vars that, if present in the runner, would change skip behaviour.
_SERVICE_ENV = [
    "NOTION_TOKEN", "NOTION_PARENT_PAGE_ID",
    "GOOGLE_SERVICE_ACCOUNT_FILE",
    "MAILCHIMP_API_KEY", "MAILCHIMP_AUDIENCE_ID",
    "CANVA_ACCESS_TOKEN",
]


class TestTargetResolution(unittest.TestCase):
    def test_all_expands(self):
        self.assertEqual(resolve_targets(["all"]), list(ALL_TARGETS))

    def test_dedupe_and_order(self):
        self.assertEqual(resolve_targets(["notion", "notion", "canva"]), ["notion", "canva"])

    def test_none_and_empty(self):
        self.assertEqual(resolve_targets(["none"]), [])
        self.assertEqual(resolve_targets([]), [])

    def test_unknown_raises(self):
        with self.assertRaises(ValueError):
            resolve_targets(["facebook"])


class TestSkipWhenUnconfigured(unittest.TestCase):
    def setUp(self):
        self._saved = {k: os.environ.pop(k, None) for k in _SERVICE_ENV}

    def tearDown(self):
        for k, v in self._saved.items():
            if v is not None:
                os.environ[k] = v

    def test_nothing_configured(self):
        self.assertEqual(configured_targets(), [])

    def test_pushes_skip_without_network(self):
        week = mock_week("x")
        results = run_pushes(week, "md", topic="x", targets=list(ALL_TARGETS))
        self.assertEqual(len(results), len(ALL_TARGETS))
        for r in results:
            self.assertTrue(r.skipped, f"{r.name} should skip but did not: {r.detail}")
            self.assertFalse(r.ok)


class TestNotionBlocks(unittest.TestCase):
    def test_build_blocks_shapes(self):
        blocks = notion.build_blocks(mock_week("x", "Conversion"))
        self.assertTrue(len(blocks) > 10)
        for b in blocks:
            self.assertEqual(b["object"], "block")
            self.assertIn("type", b)
            self.assertIn(b["type"], b)  # the type key carries the payload

    def test_rich_text_truncation(self):
        long = "a" * 5000
        block = notion._p(long)
        content = block["paragraph"]["rich_text"][0]["text"]["content"]
        self.assertLessEqual(len(content), 2000)


class TestMailchimpHelpers(unittest.TestCase):
    def test_server_prefix_from_key(self):
        os.environ["MAILCHIMP_API_KEY"] = "abcdef-us21"
        os.environ.pop("MAILCHIMP_SERVER", None)
        try:
            self.assertEqual(mailchimp._server_prefix(), "us21")
        finally:
            os.environ.pop("MAILCHIMP_API_KEY", None)

    def test_explicit_server_wins(self):
        os.environ["MAILCHIMP_API_KEY"] = "abcdef-us21"
        os.environ["MAILCHIMP_SERVER"] = "us99"
        try:
            self.assertEqual(mailchimp._server_prefix(), "us99")
        finally:
            os.environ.pop("MAILCHIMP_API_KEY", None)
            os.environ.pop("MAILCHIMP_SERVER", None)


class TestRegistry(unittest.TestCase):
    def test_every_integration_has_interface(self):
        for name, mod in INTEGRATIONS.items():
            self.assertTrue(hasattr(mod, "NAME"))
            self.assertTrue(callable(mod.is_configured))
            self.assertTrue(callable(mod.push))


if __name__ == "__main__":
    unittest.main()
