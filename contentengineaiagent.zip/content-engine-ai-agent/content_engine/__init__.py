"""Meta Neo Academy content engine.

Turn one topic, chapter, or idea into a week of on-brand Instagram content
(hooks, Reels, carousels, captions, a story sequence) via the Claude API,
then push it into Notion, Google Drive, Mailchimp, and Canva.
"""

from .models import (
    Caption,
    Carousel,
    CarouselSlide,
    ContentWeek,
    Reel,
    StoryFrame,
    StorySequence,
)

__version__ = "0.1.0"

__all__ = [
    "ContentWeek",
    "Reel",
    "Carousel",
    "CarouselSlide",
    "Caption",
    "StoryFrame",
    "StorySequence",
    "__version__",
]
