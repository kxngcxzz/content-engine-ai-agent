"""Configuration: env loading, defaults, and shared brand constants."""

from __future__ import annotations

import os

# Load a local .env if python-dotenv is installed. Harmless if it isn't.
try:  # pragma: no cover - trivial
    from dotenv import load_dotenv

    load_dotenv()
except Exception:  # pragma: no cover
    pass

DEFAULT_MODEL = os.environ.get("CONTENT_ENGINE_MODEL", "claude-opus-4-8")

# Max output tokens for the generation call. 16k comfortably fits a week of
# content plus adaptive-thinking tokens while staying under SDK HTTP timeouts.
MAX_TOKENS = 16000

VALID_GAPS = ("Visibility", "Audience", "Conversion", "Not specified")

# The rotation of soft CTAs the brand uses on cold content.
SOFT_CTAS = (
    "Free guide in bio: Social Media Monetisation 2026",
    "I broke the full system down in a free guide — link in bio",
    "Comment [WORD] and I'll send you the free guide",
    "Save this for when you actually sit down to post",
)


def normalise_gap(gap: str | None) -> str:
    """Map loose user input ('conversion', 'not sure') to a canonical gap."""
    if not gap:
        return "Not specified"
    g = gap.strip().lower()
    for canonical in VALID_GAPS:
        if g == canonical.lower() or g in canonical.lower():
            return canonical
    if g in {"not sure", "unsure", "none", "n/a", "na"}:
        return "Not specified"
    return "Not specified"
