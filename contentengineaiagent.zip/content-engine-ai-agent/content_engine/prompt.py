"""Load the brand system prompt and build the per-run user prompt."""

from __future__ import annotations

from pathlib import Path

from .config import SOFT_CTAS

_PROMPT_PATH = Path(__file__).resolve().parent / "prompts" / "meta_neo_system_prompt.md"


def load_system_prompt() -> str:
    return _PROMPT_PATH.read_text(encoding="utf-8")


def build_user_prompt(
    topic: str,
    gap: str = "Not specified",
    emphasis: str | None = None,
    source_text: str | None = None,
) -> str:
    """Assemble the user turn. The brand rules live in the system prompt;
    this turn supplies the input and the concrete deliverable spec."""
    lines: list[str] = []
    lines.append(f"INPUT TOPIC / IDEA:\n{topic.strip()}")

    if source_text and source_text.strip():
        lines.append(
            "SOURCE MATERIAL (draw the content from this — don't invent claims "
            f"beyond it):\n{source_text.strip()}"
        )

    lines.append(f"WHICH GAP THIS RELATES TO: {gap}")

    if emphasis and emphasis.strip():
        lines.append(f"EMPHASIS FOR THIS BATCH: {emphasis.strip()}")

    cta_block = "\n".join(f"- {c}" for c in SOFT_CTAS)
    lines.append(
        "Now produce a full week of content for this input, following every "
        "brand rule. Counts are strict: exactly 5 hooks, 3 Reel scripts, "
        "2 carousels (5–7 slides each), 3 captions (5–8 hashtags each, no # "
        "symbol), and 1 story sequence of 3–4 frames.\n\n"
        "Rotate these soft CTAs across the pieces — don't repeat one everywhere:\n"
        f"{cta_block}\n\n"
        "Return the result in the required structured format."
    )
    return "\n\n".join(lines)
