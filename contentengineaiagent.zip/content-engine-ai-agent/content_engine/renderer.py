"""Render a ContentWeek into copy-paste-ready Markdown and email HTML."""

from __future__ import annotations

import html
from datetime import date

from .models import Caption, Carousel, ContentWeek, Reel, StorySequence


def _hashtags_line(tags: list[str]) -> str:
    return " ".join(f"#{t.lstrip('#')}" for t in tags)


def to_markdown(week: ContentWeek, *, model: str = "", generated_on: str | None = None) -> str:
    generated_on = generated_on or date.today().isoformat()
    out: list[str] = []

    out.append("# Meta Neo Academy — Weekly Content")
    out.append(
        f"**Topic:** {week.topic}  \n"
        f"**Gap:** {week.gap}  \n"
        f"**Generated:** {generated_on}"
        + (f" · `{model}`" if model else "")
    )
    out.append("---")

    # 1. Hooks
    out.append("## 1. Hooks")
    out.append("\n".join(f"{i}. {hook}" for i, hook in enumerate(week.hooks, 1)))

    # 2. Reels
    out.append("## 2. Reel scripts (30–45s)")
    for i, reel in enumerate(week.reels, 1):
        out.append(_reel_md(i, reel))

    # 3. Carousels
    out.append("## 3. Carousels")
    for i, carousel in enumerate(week.carousels, 1):
        out.append(_carousel_md(i, carousel))

    # 4. Captions
    out.append("## 4. Captions")
    for i, caption in enumerate(week.captions, 1):
        out.append(_caption_md(i, caption))

    # 5. Story
    out.append("## 5. Story sequence")
    out.append(_story_md(week.story))

    return "\n\n".join(out).rstrip() + "\n"


def _reel_md(i: int, reel: Reel) -> str:
    lines = [f"### Reel {i}: {reel.title}", f"**Hook:** {reel.hook}", "", "**Beats:**"]
    lines += [f"- {b}" for b in reel.beats]
    lines.append("")
    lines.append("**On-screen text:**")
    lines += [f"- {t}" for t in reel.on_screen_text]
    lines.append("")
    lines.append(f"**CTA:** {reel.soft_cta}")
    return "\n".join(lines)


def _carousel_md(i: int, carousel: Carousel) -> str:
    lines = [f"### Carousel {i}", f"**Cover:** {carousel.cover_hook}", ""]
    for n, slide in enumerate(carousel.slides, 1):
        lines.append(f"**Slide {n} — {slide.heading}**  \n{slide.body}")
        lines.append("")
    lines.append(f"**CTA slide:** {carousel.cta_slide}")
    return "\n".join(lines)


def _caption_md(i: int, caption: Caption) -> str:
    lines = [f"### Caption {i}", f"> {caption.first_line}", ""]
    lines += caption.body_paragraphs
    lines.append("")
    lines.append(f"**CTA:** {caption.soft_cta}")
    lines.append("")
    lines.append(_hashtags_line(caption.hashtags))
    return "\n".join(lines)


def _story_md(story: StorySequence) -> str:
    lines: list[str] = []
    for n, frame in enumerate(story.frames, 1):
        lines.append(f"**Frame {n}:** {frame.text}  \n_({frame.note})_")
        lines.append("")
    lines.append(f"**CTA:** {story.cta}")
    return "\n".join(lines)


# ── Email HTML (used by the Mailchimp integration) ───────────────────────

def to_email_html(week: ContentWeek) -> str:
    """A simple, on-brand HTML body for a Mailchimp draft campaign."""

    def esc(s: str) -> str:
        return html.escape(s)

    parts: list[str] = []
    parts.append(
        '<div style="font-family:Helvetica,Arial,sans-serif;max-width:600px;'
        'margin:0 auto;color:#1a1a1a;line-height:1.5">'
    )
    parts.append(f"<h1 style='font-size:22px'>This week: {esc(week.topic)}</h1>")
    parts.append(
        f"<p style='color:#666;font-size:13px'>Gap focus: {esc(week.gap)}</p>"
    )

    parts.append("<h2 style='font-size:18px'>Hooks to test</h2><ul>")
    for hook in week.hooks:
        parts.append(f"<li>{esc(hook)}</li>")
    parts.append("</ul>")

    if week.captions:
        cap = week.captions[0]
        parts.append("<h2 style='font-size:18px'>Featured caption</h2>")
        parts.append(f"<p><strong>{esc(cap.first_line)}</strong></p>")
        for para in cap.body_paragraphs:
            parts.append(f"<p>{esc(para)}</p>")
        parts.append(
            f"<p style='color:#444'><em>{esc(cap.soft_cta)}</em></p>"
        )

    parts.append("</div>")
    return "".join(parts)
