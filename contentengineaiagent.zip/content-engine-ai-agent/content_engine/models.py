"""Typed data model for a week of content.

Plain stdlib dataclasses so the renderer, mock mode, and tests run with no
third-party dependencies. The Claude structured-output call validates against
the JSON schema in ``schema.py`` and is parsed back into these classes.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


class ContentError(ValueError):
    """Raised when model output doesn't match the expected shape."""


def _require(data: dict, key: str, kind: type) -> Any:
    if key not in data:
        raise ContentError(f"missing required field: {key!r}")
    value = data[key]
    if not isinstance(value, kind):
        raise ContentError(
            f"field {key!r} should be {kind.__name__}, got {type(value).__name__}"
        )
    return value


def _str_list(data: dict, key: str) -> list[str]:
    value = _require(data, key, list)
    return [str(v) for v in value]


@dataclass
class Reel:
    title: str
    hook: str
    beats: list[str]
    on_screen_text: list[str]
    soft_cta: str

    @classmethod
    def from_dict(cls, d: dict) -> "Reel":
        return cls(
            title=_require(d, "title", str),
            hook=_require(d, "hook", str),
            beats=_str_list(d, "beats"),
            on_screen_text=_str_list(d, "on_screen_text"),
            soft_cta=_require(d, "soft_cta", str),
        )


@dataclass
class CarouselSlide:
    heading: str
    body: str

    @classmethod
    def from_dict(cls, d: dict) -> "CarouselSlide":
        return cls(heading=_require(d, "heading", str), body=_require(d, "body", str))


@dataclass
class Carousel:
    cover_hook: str
    slides: list[CarouselSlide]
    cta_slide: str

    @classmethod
    def from_dict(cls, d: dict) -> "Carousel":
        slides = _require(d, "slides", list)
        return cls(
            cover_hook=_require(d, "cover_hook", str),
            slides=[CarouselSlide.from_dict(s) for s in slides],
            cta_slide=_require(d, "cta_slide", str),
        )


@dataclass
class Caption:
    first_line: str
    body_paragraphs: list[str]
    soft_cta: str
    hashtags: list[str]

    @classmethod
    def from_dict(cls, d: dict) -> "Caption":
        return cls(
            first_line=_require(d, "first_line", str),
            body_paragraphs=_str_list(d, "body_paragraphs"),
            soft_cta=_require(d, "soft_cta", str),
            hashtags=[str(h).lstrip("#") for h in _require(d, "hashtags", list)],
        )


@dataclass
class StoryFrame:
    text: str
    note: str

    @classmethod
    def from_dict(cls, d: dict) -> "StoryFrame":
        return cls(text=_require(d, "text", str), note=_require(d, "note", str))


@dataclass
class StorySequence:
    frames: list[StoryFrame]
    cta: str

    @classmethod
    def from_dict(cls, d: dict) -> "StorySequence":
        frames = _require(d, "frames", list)
        return cls(
            frames=[StoryFrame.from_dict(f) for f in frames],
            cta=_require(d, "cta", str),
        )


@dataclass
class ContentWeek:
    topic: str
    gap: str
    hooks: list[str]
    reels: list[Reel]
    carousels: list[Carousel]
    captions: list[Caption]
    story: StorySequence

    @classmethod
    def from_dict(cls, d: dict) -> "ContentWeek":
        return cls(
            topic=_require(d, "topic", str),
            gap=_require(d, "gap", str),
            hooks=_str_list(d, "hooks"),
            reels=[Reel.from_dict(r) for r in _require(d, "reels", list)],
            carousels=[Carousel.from_dict(c) for c in _require(d, "carousels", list)],
            captions=[Caption.from_dict(c) for c in _require(d, "captions", list)],
            story=StorySequence.from_dict(_require(d, "story", dict)),
        )

    def to_dict(self) -> dict:
        return asdict(self)

    def count_summary(self) -> str:
        return (
            f"{len(self.hooks)} hooks, {len(self.reels)} reels, "
            f"{len(self.carousels)} carousels, {len(self.captions)} captions, "
            f"{len(self.story.frames)}-frame story"
        )
