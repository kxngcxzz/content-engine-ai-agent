"""Deterministic, on-brand-ish mock content.

Lets you run the full pipeline (render + push) and the test suite without an
API key. Enable with ``--mock``. Output is clearly placeholder copy.
"""

from __future__ import annotations

from .config import SOFT_CTAS
from .models import (
    Caption,
    Carousel,
    CarouselSlide,
    ContentWeek,
    Reel,
    StoryFrame,
    StorySequence,
)


def mock_week(topic: str, gap: str = "Not specified") -> ContentWeek:
    t = topic.strip() or "your offer"

    hooks = [
        f"Everyone's optimising hooks for “{t}”. The hook isn't the problem.",
        f"You don't have a {t} problem. You have a Visibility Gap.",
        f"Why your best {t} post still flopped (it's the Sample Group of 200).",
        f"Stop posting more about {t}. Start posting for one game at a time.",
        f"The boring reason {t} content doesn't convert — and the fix.",
    ]

    reels = [
        Reel(
            title=f"The system behind {t}",
            hook=f"Most {t} advice fixes symptoms. Here's the cause.",
            beats=[
                "Attention is one connected system: content, audience, conversion.",
                "Pick the game first — awareness or conversion. Not both at once.",
                "Match the post to the gap you're actually trying to close.",
            ],
            on_screen_text=["Symptoms vs cause", "Pick ONE game", "Close the gap"],
            soft_cta=SOFT_CTAS[0],
        ),
        Reel(
            title="Sample Group of 200",
            hook="Your post is tested on ~200 people before anyone else sees it.",
            beats=[
                "The first 200 decide whether it travels.",
                "Make the first 3 seconds non-obvious and implementable.",
                "If those 200 don't act, the reach never comes.",
            ],
            on_screen_text=["~200 first", "Non-obvious", "Earn the reach"],
            soft_cta=SOFT_CTAS[3],
        ),
        Reel(
            title="One platform, deep",
            hook=f"Spreading {t} across 5 platforms is why none of them work.",
            beats=[
                "Go deep on one platform before you expand.",
                "Depth builds the audience that actually converts.",
                "Width just splits your attention and your data.",
            ],
            on_screen_text=["One platform", "Go deep", "Then expand"],
            soft_cta=SOFT_CTAS[1],
        ),
    ]

    carousels = [
        Carousel(
            cover_hook=f"The 3 Gaps killing your {t} (most fix the wrong one)",
            slides=[
                CarouselSlide(heading="The Visibility Gap", body="If the right people never see it, nothing else matters."),
                CarouselSlide(heading="The Audience Gap", body="Being seen by the wrong people looks like growth and pays nothing."),
                CarouselSlide(heading="The Conversion Gap", body="Attention that never becomes a customer is a hobby, not a business."),
                CarouselSlide(heading="Diagnose first", body="Find which gap is actually open before you change tactics."),
                CarouselSlide(heading="One gap at a time", body="Fixing all three at once fixes none of them."),
            ],
            cta_slide=SOFT_CTAS[1],
        ),
        Carousel(
            cover_hook=f"How to make {t} content the algorithm pushes",
            slides=[
                CarouselSlide(heading="Relevant topic", body="Speak to a problem your people already feel."),
                CarouselSlide(heading="Non-obvious", body="Say the thing they haven't heard a hundred times."),
                CarouselSlide(heading="Implementable", body="Give one step they can act on today."),
                CarouselSlide(heading="High absorption", body="Make it easy to take in — short lines, white space."),
                CarouselSlide(heading="Short distance", body="Cut the gap between watching and doing."),
            ],
            cta_slide=SOFT_CTAS[3],
        ),
    ]

    captions = [
        Caption(
            first_line=f"Your {t} content isn't underperforming. It's mis-aimed.",
            body_paragraphs=[
                "Most entrepreneurs optimise the symptoms — hooks, hashtags, posting times.",
                "The cause sits underneath: which gap you're closing, and which game you're playing.",
                "Name the gap. Pick the game. The tactics get obvious after that.",
            ],
            soft_cta=SOFT_CTAS[0],
            hashtags=["socialmediamarketing", "contentstrategy", "monetisation", "creatoreconomy", "smallbusinessuk"],
        ),
        Caption(
            first_line="Reach isn't luck. It's a test you can pass on purpose.",
            body_paragraphs=[
                "Every post is shown to a small sample group first.",
                "Make those first seconds non-obvious and easy to act on, and the reach follows.",
            ],
            soft_cta=SOFT_CTAS[3],
            hashtags=["instagramgrowth", "reelsstrategy", "audiencebuilding", "contentcreators", "digitalmarketing"],
        ),
        Caption(
            first_line="Posting everywhere is why nothing's working.",
            body_paragraphs=[
                "One platform, deep, beats five platforms, shallow.",
                "Depth is what builds the audience that actually buys.",
            ],
            soft_cta=SOFT_CTAS[2].replace("[WORD]", "SYSTEM"),
            hashtags=["onlinebusiness", "marketingtips", "personalbrand", "entrepreneurship", "growthstrategy"],
        ),
    ]

    story = StorySequence(
        frames=[
            StoryFrame(text=f"Quick one: what's your biggest {t} struggle right now?", note="question box sticker"),
            StoryFrame(text="Most answers map to one of the 3 Gaps. Here's the map ↓", note="talking head"),
            StoryFrame(text="Visibility / Audience / Conversion — which one's open for you?", note="poll sticker (3 options)"),
        ],
        cta=SOFT_CTAS[1],
    )

    return ContentWeek(
        topic=t,
        gap=gap,
        hooks=hooks,
        reels=reels,
        carousels=carousels,
        captions=captions,
        story=story,
    )
