"""Save the week's Markdown to Google Drive (as a Google Doc).

Requires:
  GOOGLE_SERVICE_ACCOUNT_FILE  path to a service-account JSON key
  GDRIVE_FOLDER_ID             (optional) destination folder, shared with the SA
"""

from __future__ import annotations

from datetime import date

from ..models import ContentWeek
from .base import PushResult, env, missing_dep

NAME = "Google Drive"
_SCOPES = ["https://www.googleapis.com/auth/drive.file"]


def is_configured() -> bool:
    return bool(env("GOOGLE_SERVICE_ACCOUNT_FILE"))


def push(week: ContentWeek, markdown: str, *, topic: str) -> PushResult:
    if not is_configured():
        return PushResult.skip(NAME, "set GOOGLE_SERVICE_ACCOUNT_FILE")
    try:
        from google.oauth2 import service_account
        from googleapiclient.discovery import build
        from googleapiclient.http import MediaInMemoryUpload
    except ImportError:
        return missing_dep(NAME, "google-api-python-client google-auth", "gdrive")

    try:
        creds = service_account.Credentials.from_service_account_file(
            env("GOOGLE_SERVICE_ACCOUNT_FILE"), scopes=_SCOPES
        )
        service = build("drive", "v3", credentials=creds, cache_discovery=False)

        name = f"Meta Neo — {topic} — {date.today().isoformat()}"
        folder = env("GDRIVE_FOLDER_ID")
        body = {"name": name}
        if folder:
            body["parents"] = [folder]
        media = MediaInMemoryUpload(markdown.encode("utf-8"), mimetype="text/markdown")

        # Try a native Google Doc (Drive converts markdown); fall back to a .md file.
        try:
            doc_body = dict(body, mimeType="application/vnd.google-apps.document")
            file = (
                service.files()
                .create(body=doc_body, media_body=media, fields="id,webViewLink",
                        supportsAllDrives=True)
                .execute()
            )
            return PushResult.success(NAME, "created Google Doc", file.get("webViewLink"))
        except Exception:
            md_body = dict(body, name=name + ".md")
            file = (
                service.files()
                .create(body=md_body, media_body=media, fields="id,webViewLink",
                        supportsAllDrives=True)
                .execute()
            )
            return PushResult.success(NAME, "uploaded .md file", file.get("webViewLink"))
    except Exception as exc:  # pragma: no cover - network
        return PushResult.failure(NAME, f"{type(exc).__name__}: {exc}")
