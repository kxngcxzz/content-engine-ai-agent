"""Create a DRAFT Mailchimp campaign from the week's content (never sends).

Requires:
  MAILCHIMP_API_KEY     e.g. "abc123...-us21" (suffix is the server prefix)
  MAILCHIMP_AUDIENCE_ID list/audience ID
Optional:
  MAILCHIMP_SERVER      server prefix if not derivable from the key
  MAILCHIMP_FROM_NAME, MAILCHIMP_REPLY_TO
"""

from __future__ import annotations

from ..models import ContentWeek
from ..renderer import to_email_html
from .base import PushResult, env, missing_dep

NAME = "Mailchimp"


def is_configured() -> bool:
    return bool(env("MAILCHIMP_API_KEY") and env("MAILCHIMP_AUDIENCE_ID"))


def _server_prefix() -> str:
    explicit = env("MAILCHIMP_SERVER")
    if explicit:
        return explicit
    key = env("MAILCHIMP_API_KEY")
    return key.split("-")[-1] if "-" in key else ""


def push(week: ContentWeek, markdown: str, *, topic: str) -> PushResult:
    if not is_configured():
        return PushResult.skip(NAME, "set MAILCHIMP_API_KEY and MAILCHIMP_AUDIENCE_ID")
    try:
        import mailchimp_marketing as MailchimpMarketing
        from mailchimp_marketing.api_client import ApiClientError
    except ImportError:
        return missing_dep(NAME, "mailchimp-marketing", "mailchimp")

    server = _server_prefix()
    if not server:
        return PushResult.failure(
            NAME, "could not determine server prefix — set MAILCHIMP_SERVER"
        )

    subject = week.captions[0].first_line if week.captions else f"This week: {topic}"
    try:
        client = MailchimpMarketing.Client()
        client.set_config({"api_key": env("MAILCHIMP_API_KEY"), "server": server})

        campaign = client.campaigns.create(
            {
                "type": "regular",
                "recipients": {"list_id": env("MAILCHIMP_AUDIENCE_ID")},
                "settings": {
                    "subject_line": subject[:150],
                    "title": f"Meta Neo — {topic}"[:100],
                    "from_name": env("MAILCHIMP_FROM_NAME") or "Meta Neo Academy",
                    "reply_to": env("MAILCHIMP_REPLY_TO") or "hello@example.com",
                },
            }
        )
        client.campaigns.set_content(campaign["id"], {"html": to_email_html(week)})
        return PushResult.success(
            NAME,
            f"created draft campaign {campaign['id']}",
            campaign.get("long_archive_url"),
        )
    except ApiClientError as exc:  # pragma: no cover - network
        return PushResult.failure(NAME, f"API error: {getattr(exc, 'text', exc)}")
    except Exception as exc:  # pragma: no cover - network
        return PushResult.failure(NAME, f"{type(exc).__name__}: {exc}")
