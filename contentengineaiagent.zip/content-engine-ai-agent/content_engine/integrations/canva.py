"""Create Canva designs for the carousels via the Canva Connect API.

For each carousel this creates a 1080×1080 design titled with the cover hook,
so you've got a draft to drop the slide copy into (the slide text is in the
Markdown / Notion / Drive outputs). If CANVA_BRAND_TEMPLATE_ID is set, the
Autofill API path is used instead to populate a Brand Template.

Requires:
  CANVA_ACCESS_TOKEN        OAuth token with design:content:write scope
Optional:
  CANVA_BRAND_TEMPLATE_ID   Brand Template to autofill (Enterprise)

Docs: https://www.canva.dev/docs/connect/
"""

from __future__ import annotations

from ..models import ContentWeek
from .base import PushResult, env, missing_dep

NAME = "Canva"
_API = "https://api.canva.com/rest/v1"
_TIMEOUT = 30


def is_configured() -> bool:
    return bool(env("CANVA_ACCESS_TOKEN"))


def _headers() -> dict:
    return {
        "Authorization": f"Bearer {env('CANVA_ACCESS_TOKEN')}",
        "Content-Type": "application/json",
    }


def _create_design(requests, title: str) -> str | None:
    resp = requests.post(
        f"{_API}/designs",
        headers=_headers(),
        json={
            "design_type": {"type": "custom", "width": 1080, "height": 1080},
            "title": title[:255],
        },
        timeout=_TIMEOUT,
    )
    resp.raise_for_status()
    design = resp.json().get("design", {})
    return design.get("urls", {}).get("edit_url") or design.get("url")


def push(week: ContentWeek, markdown: str, *, topic: str) -> PushResult:
    if not is_configured():
        return PushResult.skip(NAME, "set CANVA_ACCESS_TOKEN")
    try:
        import requests
    except ImportError:
        return missing_dep(NAME, "requests", "canva")

    try:
        urls: list[str] = []
        for carousel in week.carousels:
            url = _create_design(requests, carousel.cover_hook or topic)
            if url:
                urls.append(url)

        if not urls:
            return PushResult.failure(NAME, "no designs were created")

        detail = f"created {len(urls)} design(s) — fill with the carousel copy"
        if len(urls) > 1:
            detail += "\n     " + "\n     ".join(urls[1:])
        return PushResult.success(NAME, detail, urls[0])
    except Exception as exc:  # pragma: no cover - network
        # requests.HTTPError carries the response body, which is the useful bit.
        body = getattr(getattr(exc, "response", None), "text", "")
        return PushResult.failure(NAME, f"{type(exc).__name__}: {exc} {body}".strip())
