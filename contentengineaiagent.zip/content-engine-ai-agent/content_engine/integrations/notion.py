"""Push a week of content to Notion as a sub-page of a parent page.

Requires:
  NOTION_TOKEN           internal integration token
  NOTION_PARENT_PAGE_ID  a page shared with the integration
"""

from __future__ import annotations

from datetime import date

from ..models import Caption, Carousel, ContentWeek, Reel, StorySequence
from .base import PushResult, env, missing_dep

NAME = "Notion"
_MAX_TEXT = 1900  # Notion rich_text hard limit is 2000 chars/segment


def is_configured() -> bool:
    return bool(env("NOTION_TOKEN") and env("NOTION_PARENT_PAGE_ID"))


# ── block builders ───────────────────────────────────────────────────────

def _rt(text: str) -> list[dict]:
    return [{"type": "text", "text": {"content": text[:_MAX_TEXT]}}]


def _h2(text: str) -> dict:
    return {"object": "block", "type": "heading_2", "heading_2": {"rich_text": _rt(text)}}


def _h3(text: str) -> dict:
    return {"object": "block", "type": "heading_3", "heading_3": {"rich_text": _rt(text)}}


def _p(text: str) -> dict:
    return {"object": "block", "type": "paragraph", "paragraph": {"rich_text": _rt(text)}}


def _bullet(text: str) -> dict:
    return {
        "object": "block",
        "type": "bulleted_list_item",
        "bulleted_list_item": {"rich_text": _rt(text)},
    }


def _numbered(text: str) -> dict:
    return {
        "object": "block",
        "type": "numbered_list_item",
        "numbered_list_item": {"rich_text": _rt(text)},
    }


def _divider() -> dict:
    return {"object": "block", "type": "divider", "divider": {}}


def build_blocks(week: ContentWeek) -> list[dict]:
    blocks: list[dict] = []
    blocks.append(_p(f"Gap: {week.gap} · Generated: {date.today().isoformat()}"))

    blocks.append(_h2("1. Hooks"))
    blocks += [_numbered(h) for h in week.hooks]

    blocks.append(_h2("2. Reel scripts (30–45s)"))
    for i, reel in enumerate(week.reels, 1):
        blocks += _reel_blocks(i, reel)

    blocks.append(_h2("3. Carousels"))
    for i, carousel in enumerate(week.carousels, 1):
        blocks += _carousel_blocks(i, carousel)

    blocks.append(_h2("4. Captions"))
    for i, caption in enumerate(week.captions, 1):
        blocks += _caption_blocks(i, caption)

    blocks.append(_h2("5. Story sequence"))
    blocks += _story_blocks(week.story)

    return blocks


def _reel_blocks(i: int, reel: Reel) -> list[dict]:
    out = [_h3(f"Reel {i}: {reel.title}"), _p(f"Hook: {reel.hook}")]
    out += [_bullet(f"Beat: {b}") for b in reel.beats]
    out += [_bullet(f"On-screen: {t}") for t in reel.on_screen_text]
    out.append(_p(f"CTA: {reel.soft_cta}"))
    return out


def _carousel_blocks(i: int, carousel: Carousel) -> list[dict]:
    out = [_h3(f"Carousel {i}"), _p(f"Cover: {carousel.cover_hook}")]
    for n, slide in enumerate(carousel.slides, 1):
        out.append(_bullet(f"Slide {n} — {slide.heading}: {slide.body}"))
    out.append(_p(f"CTA slide: {carousel.cta_slide}"))
    return out


def _caption_blocks(i: int, caption: Caption) -> list[dict]:
    out = [_h3(f"Caption {i}"), _p(caption.first_line)]
    out += [_p(par) for par in caption.body_paragraphs]
    out.append(_p(f"CTA: {caption.soft_cta}"))
    out.append(_p(" ".join(f"#{t}" for t in caption.hashtags)))
    return out


def _story_blocks(story: StorySequence) -> list[dict]:
    out: list[dict] = []
    for n, frame in enumerate(story.frames, 1):
        out.append(_bullet(f"Frame {n}: {frame.text} ({frame.note})"))
    out.append(_p(f"CTA: {story.cta}"))
    return out


def _chunked(items: list, size: int = 100):
    for i in range(0, len(items), size):
        yield items[i : i + size]


def push(week: ContentWeek, markdown: str, *, topic: str) -> PushResult:
    if not is_configured():
        return PushResult.skip(NAME, "set NOTION_TOKEN and NOTION_PARENT_PAGE_ID")
    try:
        from notion_client import Client
    except ImportError:
        return missing_dep(NAME, "notion-client", "notion")

    try:
        client = Client(auth=env("NOTION_TOKEN"))
        title = f"{topic} — {date.today().isoformat()}"
        blocks = build_blocks(week)

        page = client.pages.create(
            parent={"page_id": env("NOTION_PARENT_PAGE_ID")},
            properties={"title": {"title": [{"text": {"content": title[:_MAX_TEXT]}}]}},
            children=blocks[:100],
        )
        for chunk in _chunked(blocks[100:], 100):
            client.blocks.children.append(block_id=page["id"], children=chunk)

        return PushResult.success(
            NAME, f"created page with {len(blocks)} blocks", page.get("url")
        )
    except Exception as exc:  # pragma: no cover - network
        return PushResult.failure(NAME, f"{type(exc).__name__}: {exc}")
