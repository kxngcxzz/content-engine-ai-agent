"""Push integrations: Notion, Google Drive, Mailchimp, Canva."""

from __future__ import annotations

from ..models import ContentWeek
from . import canva, google_drive, mailchimp, notion
from .base import PushResult

# Stable target keys → module. Order defines display order.
INTEGRATIONS = {
    "notion": notion,
    "gdrive": google_drive,
    "mailchimp": mailchimp,
    "canva": canva,
}

ALL_TARGETS = tuple(INTEGRATIONS.keys())


def resolve_targets(targets: list[str] | None) -> list[str]:
    """Expand 'all' / validate target keys. Returns an ordered, de-duped list."""
    if not targets:
        return []
    requested: list[str] = []
    for t in targets:
        t = t.strip().lower()
        if not t or t == "none":
            continue
        if t == "all":
            requested.extend(ALL_TARGETS)
        elif t in INTEGRATIONS:
            requested.append(t)
        else:
            raise ValueError(
                f"unknown push target {t!r}; choose from {', '.join(ALL_TARGETS)}, all"
            )
    # de-dupe, keep order
    seen: set[str] = set()
    return [t for t in requested if not (t in seen or seen.add(t))]


def configured_targets() -> list[str]:
    return [name for name, mod in INTEGRATIONS.items() if mod.is_configured()]


def run_pushes(
    week: ContentWeek, markdown: str, *, topic: str, targets: list[str]
) -> list[PushResult]:
    results: list[PushResult] = []
    for name in targets:
        mod = INTEGRATIONS[name]
        try:
            results.append(mod.push(week, markdown, topic=topic))
        except Exception as exc:  # pragma: no cover - defensive
            results.append(PushResult.failure(mod.NAME, f"{type(exc).__name__}: {exc}"))
    return results
