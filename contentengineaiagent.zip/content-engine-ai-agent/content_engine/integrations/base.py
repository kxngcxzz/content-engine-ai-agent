"""Shared types for push integrations."""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass
class PushResult:
    name: str
    ok: bool = False
    skipped: bool = False
    detail: str = ""
    url: str | None = None

    @classmethod
    def skip(cls, name: str, detail: str) -> "PushResult":
        return cls(name=name, skipped=True, detail=detail)

    @classmethod
    def success(cls, name: str, detail: str, url: str | None = None) -> "PushResult":
        return cls(name=name, ok=True, detail=detail, url=url)

    @classmethod
    def failure(cls, name: str, detail: str) -> "PushResult":
        return cls(name=name, ok=False, detail=detail)

    def line(self) -> str:
        if self.skipped:
            icon = "○"
        elif self.ok:
            icon = "✓"
        else:
            icon = "✗"
        bits = [f"{icon} {self.name}: {self.detail}"]
        if self.url:
            bits.append(f"  → {self.url}")
        return "\n".join(bits)


def env(name: str, default: str = "") -> str:
    return os.environ.get(name, default).strip()


def missing_dep(name: str, package: str, extra: str) -> PushResult:
    return PushResult.skip(
        name,
        f"{package} not installed — `pip install {package}` (or `pip install -e \".[{extra}]\"`)",
    )
