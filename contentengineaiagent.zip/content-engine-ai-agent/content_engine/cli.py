"""Command-line interface for the Meta Neo content engine."""

from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import date
from pathlib import Path

from . import __version__
from .config import DEFAULT_MODEL, VALID_GAPS, normalise_gap
from .integrations import (
    ALL_TARGETS,
    configured_targets,
    resolve_targets,
    run_pushes,
)
from .renderer import to_markdown


def _slug(text: str, limit: int = 50) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return (s[:limit].rstrip("-")) or "content"


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="content-engine",
        description="Turn one topic into a week of Meta Neo Academy Instagram content.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "examples:\n"
            '  content-engine "the 3 gap framework" --gap conversion\n'
            '  content-engine "hooks that convert" --push notion,gdrive\n'
            '  content-engine --input-file chapter3.md --mock\n'
        ),
    )
    p.add_argument("topic", nargs="?", help="the topic, chapter title, or rough idea")
    p.add_argument("--topic", dest="topic_opt", help="alternative to the positional topic")
    p.add_argument(
        "--gap",
        default=None,
        help="which gap: visibility / audience / conversion / not sure",
    )
    p.add_argument("--emphasis", help="anything to emphasise for this batch")
    p.add_argument(
        "--input-file",
        type=Path,
        help="read source material (e.g. a chapter) from this file",
    )
    p.add_argument("--model", default=DEFAULT_MODEL, help=f"model (default {DEFAULT_MODEL})")
    p.add_argument("--api-key", help="Claude API key (else uses ANTHROPIC_API_KEY)")
    p.add_argument(
        "--mock",
        action="store_true",
        help="generate placeholder content without calling the API",
    )
    p.add_argument(
        "--push",
        default="",
        help=f"comma-separated targets: {', '.join(ALL_TARGETS)}, all (default: none)",
    )
    p.add_argument(
        "--out",
        type=Path,
        default=Path("output"),
        help="output directory (default ./output)",
    )
    p.add_argument("--no-save", action="store_true", help="don't write files to disk")
    p.add_argument(
        "--list-targets",
        action="store_true",
        help="show which push integrations are configured, then exit",
    )
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)

    if args.list_targets:
        configured = set(configured_targets())
        print("Push integrations:")
        for t in ALL_TARGETS:
            mark = "configured" if t in configured else "not configured"
            print(f"  {t:<10} {mark}")
        return 0

    topic = args.topic_opt or args.topic
    source_text = None
    if args.input_file:
        if not args.input_file.exists():
            print(f"error: input file not found: {args.input_file}", file=sys.stderr)
            return 2
        source_text = args.input_file.read_text(encoding="utf-8")
        if not topic:
            topic = args.input_file.stem.replace("-", " ").replace("_", " ")

    if not topic:
        print("error: provide a topic (positional, --topic, or --input-file)", file=sys.stderr)
        return 2

    gap = normalise_gap(args.gap)

    try:
        targets = resolve_targets(args.push.split(",") if args.push else [])
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    # ── generate ──────────────────────────────────────────────────────
    if args.mock:
        from .mock import mock_week

        week = mock_week(topic, gap)
        model_label = "MOCK"
        print(f"[mock] generated week for: {topic}")
    else:
        from .generator import generate

        try:
            week, meta = generate(
                topic,
                gap=gap,
                emphasis=args.emphasis,
                source_text=source_text,
                model=args.model,
                api_key=args.api_key,
            )
        except Exception as exc:
            print(f"error: generation failed: {exc}", file=sys.stderr)
            return 1
        model_label = meta.model
        toks = (
            f" · {meta.input_tokens}→{meta.output_tokens} tokens"
            if meta.output_tokens
            else ""
        )
        print(f"[ok] generated week for: {topic} ({week.count_summary()}){toks}")
        for w in meta.warnings:
            print(f"  warning: {w}", file=sys.stderr)

    markdown = to_markdown(week, model=model_label)

    # ── save ──────────────────────────────────────────────────────────
    if not args.no_save:
        args.out.mkdir(parents=True, exist_ok=True)
        stem = f"{date.today().isoformat()}-{_slug(topic)}"
        md_path = args.out / f"{stem}.md"
        json_path = args.out / f"{stem}.json"
        md_path.write_text(markdown, encoding="utf-8")
        json_path.write_text(json.dumps(week.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"[saved] {md_path}\n[saved] {json_path}")

    # ── push ──────────────────────────────────────────────────────────
    if targets:
        print(f"\nPushing to: {', '.join(targets)}")
        results = run_pushes(week, markdown, topic=topic, targets=targets)
        for r in results:
            print(r.line())
        if any((not r.ok and not r.skipped) for r in results):
            return 1

    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
