"""Generate a ContentWeek via the Claude API using structured outputs."""

from __future__ import annotations

import json
from dataclasses import dataclass

from .config import DEFAULT_MODEL, MAX_TOKENS
from .models import ContentWeek
from .prompt import build_user_prompt, load_system_prompt
from .schema import CONTENT_WEEK_SCHEMA

_EXPECTED = {"hooks": 5, "reels": 3, "carousels": 2, "captions": 3}


@dataclass
class GenerationMeta:
    model: str
    input_tokens: int | None = None
    output_tokens: int | None = None
    warnings: tuple[str, ...] = ()


def _check_counts(week: ContentWeek) -> tuple[str, ...]:
    warnings: list[str] = []
    actual = {
        "hooks": len(week.hooks),
        "reels": len(week.reels),
        "carousels": len(week.carousels),
        "captions": len(week.captions),
    }
    for key, want in _EXPECTED.items():
        if actual[key] != want:
            warnings.append(f"expected {want} {key}, got {actual[key]}")
    if not 3 <= len(week.story.frames) <= 4:
        warnings.append(f"expected 3–4 story frames, got {len(week.story.frames)}")
    return tuple(warnings)


def generate(
    topic: str,
    *,
    gap: str = "Not specified",
    emphasis: str | None = None,
    source_text: str | None = None,
    model: str = DEFAULT_MODEL,
    api_key: str | None = None,
) -> tuple[ContentWeek, GenerationMeta]:
    """Call Claude and return the parsed week plus generation metadata.

    Raises a clear RuntimeError on missing SDK, refusal, or malformed output.
    """
    try:
        import anthropic
    except ImportError as exc:  # pragma: no cover - environment dependent
        raise RuntimeError(
            "The `anthropic` package is required to generate content. "
            "Install it with `pip install anthropic` (or run with --mock)."
        ) from exc

    client = anthropic.Anthropic(api_key=api_key) if api_key else anthropic.Anthropic()

    response = client.messages.create(
        model=model,
        max_tokens=MAX_TOKENS,
        system=load_system_prompt(),
        thinking={"type": "adaptive"},
        output_config={
            "format": {"type": "json_schema", "schema": CONTENT_WEEK_SCHEMA},
            "effort": "high",
        },
        messages=[
            {
                "role": "user",
                "content": build_user_prompt(topic, gap, emphasis, source_text),
            }
        ],
    )

    if getattr(response, "stop_reason", None) == "refusal":
        detail = getattr(getattr(response, "stop_details", None), "explanation", "")
        raise RuntimeError(f"Claude refused to generate this content. {detail}".strip())

    text = next((b.text for b in response.content if getattr(b, "type", None) == "text"), None)
    if not text:
        raise RuntimeError(
            "No structured content returned "
            f"(stop_reason={getattr(response, 'stop_reason', 'unknown')})."
        )

    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Model output was not valid JSON: {exc}") from exc

    week = ContentWeek.from_dict(data)
    # Ensure the recorded topic/gap reflect the request even if the model omitted them.
    week.topic = week.topic or topic
    if gap and gap != "Not specified":
        week.gap = gap

    usage = getattr(response, "usage", None)
    meta = GenerationMeta(
        model=model,
        input_tokens=getattr(usage, "input_tokens", None),
        output_tokens=getattr(usage, "output_tokens", None),
        warnings=_check_counts(week),
    )
    return week, meta
