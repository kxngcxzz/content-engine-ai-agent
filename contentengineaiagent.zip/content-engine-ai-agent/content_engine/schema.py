"""JSON schema for the Claude structured-output call.

Hand-written to satisfy the Messages API structured-output constraints:
every object sets ``additionalProperties: false`` and lists all of its keys in
``required``; no unsupported constraints (minItems/maxItems/minLength/etc.).
Counts are guided via descriptions and the prompt, then checked in Python.
"""

from __future__ import annotations


def _obj(properties: dict, descriptions: dict | None = None) -> dict:
    descriptions = descriptions or {}
    props = {}
    for name, spec in properties.items():
        spec = dict(spec)
        if name in descriptions:
            spec["description"] = descriptions[name]
        props[name] = spec
    return {
        "type": "object",
        "additionalProperties": False,
        "properties": props,
        "required": list(properties.keys()),
    }


_STR = {"type": "string"}
_STR_LIST = {"type": "array", "items": {"type": "string"}}

_REEL = _obj(
    {
        "title": _STR,
        "hook": _STR,
        "beats": _STR_LIST,
        "on_screen_text": _STR_LIST,
        "soft_cta": _STR,
    },
    {
        "title": "Short internal label for the Reel concept.",
        "hook": "The opening line (spoken + on-screen) that stops the scroll.",
        "beats": "3–5 short spoken/voiceover beats that teach one real thing.",
        "on_screen_text": "On-screen text suggestions, one per beat or key moment.",
        "soft_cta": "A soft CTA pointing to the free guide — never a hard sell.",
    },
)

_CAROUSEL_SLIDE = _obj(
    {"heading": _STR, "body": _STR},
    {
        "heading": "Slide heading — one idea per slide.",
        "body": "1–2 short sentences expanding the slide's single idea.",
    },
)

_CAROUSEL = _obj(
    {
        "cover_hook": _STR,
        "slides": {"type": "array", "items": _CAROUSEL_SLIDE},
        "cta_slide": _STR,
    },
    {
        "cover_hook": "Cover-slide hook that earns the swipe.",
        "slides": "5–7 slides, one idea each, building one complete idea.",
        "cta_slide": "Final-slide CTA pointing to the free guide.",
    },
)

_CAPTION = _obj(
    {
        "first_line": _STR,
        "body_paragraphs": _STR_LIST,
        "soft_cta": _STR,
        "hashtags": _STR_LIST,
    },
    {
        "first_line": "Strong first line shown before the '…more' fold.",
        "body_paragraphs": "2–4 short value paragraphs in brand voice.",
        "soft_cta": "Soft CTA pointing to the free guide.",
        "hashtags": "5–8 relevant, non-spammy hashtags WITHOUT the leading # symbol.",
    },
)

_STORY_FRAME = _obj(
    {"text": _STR, "note": _STR},
    {
        "text": "The text/insight on this story frame.",
        "note": "Production note, e.g. 'poll sticker', 'talking head', 'question box'.",
    },
)

_STORY = _obj(
    {"frames": {"type": "array", "items": _STORY_FRAME}, "cta": _STR},
    {
        "frames": "3–4 casual, lower-production frames to drive replies/DMs.",
        "cta": "Closing soft CTA pointing to the free guide.",
    },
)

CONTENT_WEEK_SCHEMA = _obj(
    {
        "topic": _STR,
        "gap": _STR,
        "hooks": _STR_LIST,
        "reels": {"type": "array", "items": _REEL},
        "carousels": {"type": "array", "items": _CAROUSEL},
        "captions": {"type": "array", "items": _CAPTION},
        "story": _STORY,
    },
    {
        "topic": "The input topic this content was generated from.",
        "gap": "Which of the 3 Gaps this relates to: 'Visibility', 'Audience', "
        "'Conversion', or 'Not specified'.",
        "hooks": "Exactly 5 scroll-stopping hooks.",
        "reels": "Exactly 3 Reel scripts (30–45s each).",
        "carousels": "Exactly 2 carousel outlines.",
        "captions": "Exactly 3 captions in brand voice.",
        "story": "One story sequence of 3–4 frames.",
    },
)
