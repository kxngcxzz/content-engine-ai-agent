# Example output

These files were generated with `--mock` (no API call) to illustrate the
**shape and format** of a run. Real runs call the Claude API and produce
original, on-brand copy for your topic.

```bash
content-engine "turning followers into customers" --gap conversion \
  --emphasis "lean into the conversion angle" --mock --out output/examples
```

- `*.md`   — copy-paste-ready content, organised by section
- `*.json` — the same week as structured data (what gets pushed to integrations)
