# content-engine-ai-agent

The **Meta Neo Academy content engine**. Feed it one topic, chapter, or rough
idea — get back a week of post-ready Instagram content in the Meta Neo brand
voice: 5 hooks, 3 Reel scripts, 2 carousels, 3 captions, and a story sequence.
Then push it straight into **Notion, Google Drive, Mailchimp, and Canva**.

It's a small, reusable CLI built on the Claude API (`claude-opus-4-8`) using
structured outputs, so every run comes back as clean, typed data you can render
and publish.

```
topic ──▶ Claude (brand prompt + structured output) ──▶ ContentWeek
                                                          ├─▶ Markdown + JSON (./output)
                                                          └─▶ Notion · Google Drive · Mailchimp · Canva
```

---

## Quick start

```bash
# 1. Install (core only — add integration extras as needed, see below)
pip install -e .

# 2. Set your Claude API key
cp .env.example .env          # then edit, or just:
export ANTHROPIC_API_KEY="sk-ant-..."

# 3. Generate a week of content
content-engine "the 3 gap framework" --gap conversion
```

Output lands in `./output/` as a Markdown file (copy-paste ready) and a JSON
file (structured data). See [`output/examples/`](output/examples) for a sample.

No API key yet? Try **mock mode** — it runs the whole pipeline with placeholder
copy so you can see the format and test integrations:

```bash
content-engine "hooks that convert" --mock
```

---

## Usage

```
content-engine TOPIC [options]

  TOPIC                 the topic, chapter title, or rough idea
  --gap GAP             visibility | audience | conversion | not sure
  --emphasis TEXT       e.g. "make the carousels beginner-friendly"
  --input-file PATH     read source material (e.g. an ebook chapter) from a file
  --model MODEL         default: claude-opus-4-8
  --push TARGETS        comma list: notion,gdrive,mailchimp,canva,all  (default: none)
  --out DIR             output directory (default ./output)
  --mock                generate placeholder content without calling the API
  --no-save             don't write files to disk
  --list-targets        show which integrations are configured
  --api-key KEY         Claude API key (else uses ANTHROPIC_API_KEY)
```

### Examples

```bash
# A whole chapter as the source, pushed to Notion + Drive
content-engine --input-file chapter3.md --gap audience --push notion,gdrive

# Everything, everywhere
content-engine "the two games: awareness vs conversion" --push all

# Check what's wired up
content-engine --list-targets
```

---

## What it generates

Every run produces a `ContentWeek` (see `content_engine/models.py`):

| Section   | Count | Each contains |
|-----------|-------|---------------|
| Hooks     | 5     | a scroll-stopping opening line |
| Reels     | 3     | hook · 3–5 beats · on-screen text · soft CTA |
| Carousels | 2     | cover hook · 5–7 slides · CTA slide |
| Captions  | 3     | first line · 2–4 paragraphs · soft CTA · 5–8 hashtags |
| Story     | 1     | 3–4 frames · soft CTA |

The brand voice, frameworks (3 Gap Framework, Sample Group of 200, 4 Horsemen,
Two Games, One Platform Principle), and rules live in
[`content_engine/prompts/meta_neo_system_prompt.md`](content_engine/prompts/meta_neo_system_prompt.md).
Edit that file to tune the voice — it's the single source of truth for the prompt.

---

## Integrations

Each integration is **optional** and **skips cleanly** when its credentials
aren't set (so `--push all` only does what it can). Install just the ones you use:

```bash
pip install -e ".[notion]"      # or .[gdrive] / .[mailchimp] / .[canva] / .[all]
```

Set credentials in `.env` (see [`.env.example`](.env.example)):

| Target      | Required env vars | What it does |
|-------------|-------------------|--------------|
| **Notion** (`notion`) | `NOTION_TOKEN`, `NOTION_PARENT_PAGE_ID` | Creates a sub-page with the full week as Notion blocks |
| **Google Drive** (`gdrive`) | `GOOGLE_SERVICE_ACCOUNT_FILE` (+ optional `GDRIVE_FOLDER_ID`) | Saves the week as a Google Doc |
| **Mailchimp** (`mailchimp`) | `MAILCHIMP_API_KEY`, `MAILCHIMP_AUDIENCE_ID` | Creates a **draft** campaign (never sends) |
| **Canva** (`canva`) | `CANVA_ACCESS_TOKEN` | Creates a 1080×1080 design per carousel to drop the copy into |

Setup notes:

- **Notion** — create an internal integration at
  <https://www.notion.so/my-integrations>, then **share** the target page with it
  and use that page's ID as `NOTION_PARENT_PAGE_ID`.
- **Google Drive** — create a service account, download its JSON key, and share
  the destination folder with the service account's email.
- **Mailchimp** — the server prefix (e.g. `us21`) is taken from the suffix of
  your API key automatically; override with `MAILCHIMP_SERVER` if needed.
- **Canva** — needs a [Canva Connect](https://www.canva.dev/docs/connect/)
  OAuth token with the `design:content:write` scope. Set `CANVA_BRAND_TEMPLATE_ID`
  to autofill an Enterprise Brand Template instead of creating blank designs.

> The Canva/Notion/Drive/Mailchimp connections you may have in Claude Code (MCP)
> are separate from this CLI — the CLI talks to each service's own API with the
> credentials above, so it's portable to your machine, a cron job, or CI.

---

## Agent Skills

This repo ships [Agent Skills](https://platform.claude.com/docs/en/agents-and-tools/skills)
in [`.claude/skills/`](.claude/skills) so an agent working in this repo (e.g.
Claude Code) can drive and extend the engine:

- **meta-neo-content-engine** — wraps this CLI as a skill (one topic → a week of content).
- A curated, content-focused set imported from
  [seb1n/awesome-ai-agent-skills](https://github.com/seb1n/awesome-ai-agent-skills)
  (MIT): `content-strategy`, `social-media-posting`, `seo-optimization`,
  `keyword-research`, `copywriting`, `proofreading`, `email-drafting`.

They compose into a weekly loop: research/strategy → generate → copywriting/proofreading
→ SEO → newsletter → schedule. See [`.claude/skills/README.md`](.claude/skills/README.md).

## How it uses the Claude API

- Model: **`claude-opus-4-8`** (override with `--model` or `CONTENT_ENGINE_MODEL`).
- **Structured outputs**: the request constrains the response to a strict JSON
  schema (`content_engine/schema.py`), so output is always valid, typed data —
  no brittle text parsing. Parsed back into dataclasses in `content_engine/models.py`.
- **Adaptive thinking** is on for higher-quality strategic copy.
- Lives in `content_engine/generator.py`; everything else (render, push, mock,
  tests) runs without the SDK.

---

## Development

```bash
python -m unittest discover -s tests      # or: pytest
```

The core, renderer, mock mode, and tests have **no third-party dependencies** —
they run on a clean Python 3.10+. Only live generation needs `anthropic`, and
each push target needs its own optional package.

Project layout:

```
content_engine/
  cli.py            # argument parsing + orchestration
  generator.py      # the Claude API call (structured output)
  models.py         # ContentWeek dataclasses + parsing
  schema.py         # JSON schema for structured output
  prompt.py         # system + user prompt assembly
  renderer.py       # ContentWeek → Markdown / email HTML
  mock.py           # placeholder content for --mock
  prompts/          # the editable brand system prompt
  integrations/     # notion, google_drive, mailchimp, canva
tests/              # unittest suite (also runs under pytest)
```
