# Agent Skills

[Agent Skills](https://platform.claude.com/docs/en/agents-and-tools/skills) for
this project. Each skill is a folder with a `SKILL.md` (instructions + metadata)
that Claude Code / agents load on demand when a task matches its description.

## This project's skill

- **meta-neo-content-engine** — drives the content engine in this repo: one topic
  → a week of on-brand Instagram content, optionally pushed to Notion, Google
  Drive, Mailchimp, and Canva.

## Curated skills (imported)

A curated, content-focused set imported verbatim from
[seb1n/awesome-ai-agent-skills](https://github.com/seb1n/awesome-ai-agent-skills)
(MIT licensed — each file keeps its original `license`/`author` frontmatter):

| Skill | What it does |
|-------|--------------|
| **content-strategy** | Map content to audience needs, funnel stages, and goals; editorial planning. |
| **social-media-posting** | Adapt + schedule posts per platform with hooks and cadence. |
| **seo-optimization** | Improve on-page discoverability of captions and copy. |
| **keyword-research** | Find the topics and terms worth posting about. |
| **copywriting** | Sharpen hooks, captions, and CTAs. |
| **proofreading** | Catch errors and tighten the final copy. |
| **email-drafting** | Turn a week of content into a newsletter (pairs with Mailchimp). |

## How they fit together

```
keyword-research + content-strategy   →  pick the week's topic & angle
meta-neo-content-engine               →  generate the week of posts
copywriting + proofreading            →  sharpen and polish
seo-optimization                      →  tune for discoverability
email-drafting                        →  draft the newsletter (Mailchimp)
social-media-posting                  →  sequence & schedule
```

## Attribution

The seven imported skills come from **seb1n/awesome-ai-agent-skills** (MIT
License) and are included unmodified. See that repository for the full
collection of 90+ skills and any bundled `scripts/`, `references/`, or `assets/`.
The `meta-neo-content-engine` skill is original to this project.
