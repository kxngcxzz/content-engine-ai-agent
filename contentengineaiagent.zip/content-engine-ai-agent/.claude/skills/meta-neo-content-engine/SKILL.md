---
name: meta-neo-content-engine
description: Turn ONE topic, chapter, or idea into a full week of on-brand Meta Neo Academy Instagram content (5 hooks, 3 Reels, 2 carousels, 3 captions, a story sequence) and optionally push it to Notion, Google Drive, Mailchimp, and Canva. Use when the user wants a week of social content, to batch-produce posts, or to repurpose a topic/chapter into the Meta Neo voice.
license: MIT
metadata:
  author: content-engine-ai-agent
  version: 0.1.0
---

# Meta Neo Content Engine

This skill drives the content engine in this repository: a Python CLI that calls
the Claude API with the Meta Neo Academy brand prompt and structured outputs,
then renders a week of Instagram content and (optionally) publishes it to
connected tools. Use it whenever the user gives a topic, an ebook chapter, or a
rough idea and wants ready-to-post content in the brand voice.

The brand voice, frameworks (3 Gap Framework, Sample Group of 200, 4 Horsemen,
Two Games, One Platform Principle), and rules live in
`content_engine/prompts/meta_neo_system_prompt.md` — edit that file to tune voice.

## Workflow

1. **Confirm the input.** Get the one topic / chapter / idea. Optionally ask
   which gap it relates to (Visibility / Audience / Conversion) and any emphasis
   (e.g. "make the carousels beginner-friendly", "lean into conversion"). Don't
   over-ask — the engine works with just a topic.

2. **Check prerequisites.** Generation needs `ANTHROPIC_API_KEY`. If it's not
   set or the user just wants to see the format, run with `--mock` (no API call).
   Pushing to a tool needs that tool's credentials — see `.env.example`. Run
   `python -m content_engine --list-targets` to see what's configured.

3. **Generate.** Run the CLI:

   ```bash
   python -m content_engine "TOPIC" --gap conversion --emphasis "..."
   # or: content-engine "TOPIC" ...   (after `pip install -e .`)
   ```

   Output lands in `./output/` as Markdown (copy-paste ready) and JSON
   (structured). Read the Markdown back to the user or summarise it.

4. **Push (optional).** If the user wants it in their tools, add
   `--push notion,gdrive,mailchimp,canva` (or `--push all`). Each target skips
   cleanly if not configured. Mailchimp creates a **draft** (never sends).

5. **Refine (optional).** Compose with the other skills in `.claude/skills/`:
   tighten copy with **copywriting**, polish with **proofreading**, improve
   discoverability with **seo-optimization**, plan the cadence with
   **social-media-posting**, and draft the newsletter with **email-drafting**.

## Usage

Provide a topic; the engine returns a full week of content. Flags:

| Flag | Purpose |
|------|---------|
| `--gap` | visibility \| audience \| conversion \| not sure |
| `--emphasis` | a steer for this batch |
| `--input-file` | use an ebook chapter / source file as the material |
| `--push` | notion,gdrive,mailchimp,canva,all |
| `--mock` | generate placeholder content without an API call |
| `--no-save` | don't write files to disk |
| `--list-targets` | show which integrations are configured |

**Prompt:** `Generate a week of content on "turning followers into customers", lean into the conversion angle, and push it to Notion.`
→ `python -m content_engine "turning followers into customers" --gap conversion --emphasis "lean into conversion" --push notion`

## How it composes with the other skills

A repeatable weekly loop for the agent:

1. **keyword-research** + **content-strategy** → pick the week's topic and angle.
2. **meta-neo-content-engine** → generate the week of posts for that topic.
3. **copywriting** + **proofreading** → sharpen hooks/captions and catch errors.
4. **seo-optimization** → tune captions/hashtags for discoverability.
5. **email-drafting** → turn the week into the Mailchimp newsletter.
6. **social-media-posting** → sequence and schedule across the week.

## Best Practices

- **One topic in, one week out.** Don't batch multiple unrelated topics into a
  single run — run the engine once per topic so each week stays coherent.
- **Keep the voice in one place.** Tune the brand prompt file, not the code.
  Never add fabricated stats or fake personal results — it's a brand rule.
- **Soft CTAs only.** The engine rotates the approved free-guide CTAs; don't
  swap in hard sells on cold content.
- **Use `--mock` for format checks and demos** so you don't spend API tokens.

## Edge Cases

- **No API key:** fall back to `--mock`, and tell the user generation is
  placeholder until `ANTHROPIC_API_KEY` is set.
- **A push target errors or is unconfigured:** the run still succeeds and saves
  locally; report which targets skipped and why (the CLI prints this).
- **Count warnings** (e.g. "expected 5 hooks, got 4"): the CLI prints these to
  stderr — surface them and offer to re-run.
